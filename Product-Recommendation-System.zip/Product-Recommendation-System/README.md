# Smart Product Recommendation System

A beginner-friendly product recommendation web app built with Python and Streamlit. It recommends similar products using content-based filtering with TF-IDF and cosine similarity.

## Features

- Product catalogue with sample products from multiple categories
- Search by product name, brand, category, and description
- Category and maximum-price filters
- Recommendations based on product descriptions and features
- Similarity score for each recommendation
- Interactive Streamlit web interface

## Tech Stack

- Python
- Streamlit
- pandas
- scikit-learn
- TF-IDF Vectorization
- Cosine Similarity

## Project Structure

```text
Product-Recommendation-System/
├── app.py
├── recommender.py
├── products.csv
├── requirements.txt
├── .gitignore
└── README.md
```

## Requirements

- Python 3.11 or 3.12 recommended
- VS Code (recommended)
- Internet connection for installing packages

## Run Locally

1. Clone or download this repository.
2. Open the project folder in VS Code.
3. Create a virtual environment:

   ```bash
   python -m venv .venv
   ```

4. Activate it on Windows PowerShell:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

5. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

6. Start the app:

   ```bash
   python -m streamlit run app.py
   ```

7. Open the local URL shown in the terminal, usually `http://localhost:8501`.

If the `python` command is unavailable, try using `py` instead.

## How Recommendations Work

1. The app combines each product's category, brand, description, and features.
2. `TfidfVectorizer` converts this text into numeric vectors.
3. Cosine similarity compares the selected product with all other products.
4. The app sorts products by similarity and displays the top matches.

## Dataset

`products.csv` contains sample demonstration data. Replace it with a properly licensed dataset if using real product information. Prices and products are examples and do not represent a live store.

## Limitations

This is a content-based demo. It does not use real customer histories, live inventory, or live prices. Recommendations depend on the words in the product metadata.

## Future Improvements

- Add product images and links
- Import a larger product dataset
- Add ratings and user feedback
- Deploy the app to a hosting platform

## License

This project is provided as an educational example. Add a license file if you want to grant others specific reuse permissions.
