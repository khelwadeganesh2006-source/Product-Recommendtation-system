import pandas as pd
import streamlit as st
from recommender import load_products, recommend_products, categories

st.set_page_config(
    page_title="Smart Product Recommender",
    page_icon="🛍️",
    layout="wide",
)

st.markdown("""
<style>
    .main-title {font-size: 2.35rem; font-weight: 800; margin-bottom: 0.2rem;}
    .subtitle {color: #64748b; margin-bottom: 1.2rem;}
    .product-card {border: 1px solid rgba(128,128,128,.25); border-radius: 14px;
                   padding: 14px; height: 100%;}
    .product-name {font-size: 1.08rem; font-weight: 700;}
    .muted {color: #64748b; font-size: .9rem;}
    .price {font-size: 1.15rem; font-weight: 800;}
</style>
""", unsafe_allow_html=True)

products = load_products()

st.markdown('<div class="main-title">🛍️ Smart Product Recommender</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="subtitle">Discover products that match your interests using content-based filtering.</div>',
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("🔎 Find Products")
    search_query = st.text_input("Search products", placeholder="e.g. wireless headphones")
    selected_category = st.selectbox("Category", ["All categories"] + categories(products))
    max_price = st.slider(
        "Maximum price ($)",
        min_value=10,
        max_value=int(products["price"].max()),
        value=int(products["price"].max()),
        step=10,
    )
    st.caption("Demo catalogue with sample product data.")

filtered = products.copy()
if search_query.strip():
    query = search_query.strip().lower()
    mask = (
        filtered["name"].str.lower().str.contains(query, regex=False)
        | filtered["description"].str.lower().str.contains(query, regex=False)
        | filtered["brand"].str.lower().str.contains(query, regex=False)
        | filtered["category"].str.lower().str.contains(query, regex=False)
    )
    filtered = filtered[mask]
if selected_category != "All categories":
    filtered = filtered[filtered["category"] == selected_category]
filtered = filtered[filtered["price"] <= max_price]

tab_catalogue, tab_recommend = st.tabs(["🛒 Product Catalogue", "✨ Recommendations"])

with tab_catalogue:
    st.subheader("Explore the catalogue")
    st.write(f"Showing **{len(filtered)}** product(s).")
    if filtered.empty:
        st.info("No products match these filters. Try another search or raise the maximum price.")
    else:
        cols = st.columns(3)
        for idx, (_, product) in enumerate(filtered.iterrows()):
            with cols[idx % 3]:
                st.markdown('<div class="product-card">', unsafe_allow_html=True)
                st.markdown(f"### {product['emoji']} {product['name']}")
                st.caption(f"{product['brand']} · {product['category']}")
                st.markdown(f"<div class='price'>${product['price']:.2f}</div>", unsafe_allow_html=True)
                st.write(product["description"])
                st.markdown('</div>', unsafe_allow_html=True)
                st.write("")

with tab_recommend:
    st.subheader("Find similar products")
    product_names = products["name"].tolist()
    chosen_product = st.selectbox("Choose a product you like", product_names)
    count = st.slider("Number of recommendations", min_value=1, max_value=8, value=4)

    if st.button("Recommend Similar Products", type="primary", use_container_width=True):
        recommendations = recommend_products(products, chosen_product, top_n=count)
        st.session_state["recommendations"] = recommendations
        st.session_state["chosen_product"] = chosen_product

    if "recommendations" in st.session_state:
        chosen = st.session_state["chosen_product"]
        selected_row = products.loc[products["name"] == chosen].iloc[0]
        st.markdown("#### Your selected product")
        st.info(f"{selected_row['emoji']} **{selected_row['name']}** — ${selected_row['price']:.2f}\n\n{selected_row['description']}")

        recs = st.session_state["recommendations"]
        if recs.empty:
            st.warning("No similar products were found.")
        else:
            st.markdown("#### Recommended for you")
            cols = st.columns(2)
            for idx, (_, product) in enumerate(recs.iterrows()):
                with cols[idx % 2]:
                    st.markdown('<div class="product-card">', unsafe_allow_html=True)
                    st.markdown(f"### {product['emoji']} {product['name']}")
                    st.caption(f"{product['brand']} · {product['category']}")
                    st.markdown(f"<div class='price'>${product['price']:.2f}</div>", unsafe_allow_html=True)
                    st.write(product["description"])
                    st.progress(float(product["similarity"]), text=f"Content similarity: {product['similarity']:.0%}")
                    st.markdown('</div>', unsafe_allow_html=True)
                    st.write("")

st.divider()
st.caption("Demo project · Python · Streamlit · TF-IDF · Cosine Similarity")
