from pathlib import Path

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DATA_PATH = Path(__file__).parent / "products.csv"


def load_products():
    """Load and validate the product catalogue."""
    products = pd.read_csv(DATA_PATH)
    required_columns = {
        "product_id", "name", "category", "brand", "description",
        "features", "price", "emoji"
    }
    missing = required_columns - set(products.columns)
    if missing:
        raise ValueError(f"Missing required columns in products.csv: {sorted(missing)}")

    products["price"] = pd.to_numeric(products["price"], errors="raise")
    products["content"] = (
        products["category"].fillna("") + " "
        + products["brand"].fillna("") + " "
        + products["description"].fillna("") + " "
        + products["features"].fillna("")
    )
    return products


def categories(products):
    """Return sorted unique product categories."""
    return sorted(products["category"].dropna().unique().tolist())


def recommend_products(products, product_name, top_n=4):
    """Recommend products using TF-IDF vectors and cosine similarity."""
    if product_name not in products["name"].values:
        return pd.DataFrame(columns=list(products.columns) + ["similarity"])

    # Convert product descriptions and features into numeric TF-IDF vectors.
    vectorizer = TfidfVectorizer(stop_words="english")
    matrix = vectorizer.fit_transform(products["content"])

    selected_index = products.index[products["name"] == product_name][0]
    position = products.index.get_loc(selected_index)

    scores = cosine_similarity(matrix[position], matrix).flatten()

    result = products.copy()
    result["similarity"] = scores
    result = result[result["name"] != product_name]
    result = result.sort_values("similarity", ascending=False)

    return result.head(top_n).reset_index(drop=True)
